/*
 Copyright (c) 2018-2019 SpringCard - www.springcard.com
 All right reserved
 This software is covered by the SpringCard SDK License Agreement - see LICENSE.txt
 */
/// :nodoc:
#import <UIKit/UIKit.h>

//! Project version number for SpringCard_PCSC_ZeroDriver.
FOUNDATION_EXPORT double SpringCard_PcSc_LikeVersionNumber;

//! Project version string for SpringCard_PCSC_ZeroDriver.
FOUNDATION_EXPORT const unsigned char SpringCard_PcSc_LikeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SpringCard_PCSC_ZeroDriver/PublicHeader.h>


